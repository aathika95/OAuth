<?php
	session_start();

	require_once "Facebook/autoload.php";
	
	//Replace the app_id,app_secret with yours.
	$FB = new \Facebook\Facebook([
		'app_id' => '985685364966980',
		'app_secret' => '1e8db9b75678e4c3417cef62a5156b95',
		'default_graph_version' => 'v3.0'
	]);

	$helper = $FB->getRedirectLoginHelper();
?>
